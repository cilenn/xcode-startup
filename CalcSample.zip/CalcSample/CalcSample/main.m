//
//  main.m
//  CalcSample
//
//  Created by Ito Atsushi on 2014/07/08.
//  Copyright (c) 2014年 Ito Atsushi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
